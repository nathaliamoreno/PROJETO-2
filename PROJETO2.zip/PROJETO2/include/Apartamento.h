#ifndef APARTAMENTO_H
#define APARTAMENTO_H
#include "Endereco.h"
#include <iostream>



class Apartamento : public Endereco
{
    public:
        Apartamento();
        Apartamento(std::string pos, std::string quart, std::string And,
                    std::string areaAP, std::string vaga, std::string valorCon);

        void setPosicao(std::string pos);
        void setQuartos(std::string quartos);

        void setAndar (std::string And);
        void setAreaAPT(std::string aAP);
        void setVagas (std::string vaga);
        void setValorCondominio(std::string valorCon);

        std::string getPosicao();
        std::string getQuartos();
        std::string getAndar();
        std::string getAreaAPT();
        std::string getVagas();
        std::string getValorCondominio();


        std::string posicao;
        std::string nQuartos;
        std::string andar;
        std::string areaApt;
        std::string vagas;
        std::string valorCond;

    private:
};

#endif // APARTAMENTO_H
