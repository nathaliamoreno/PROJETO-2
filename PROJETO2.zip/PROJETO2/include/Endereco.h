#ifndef ENDERECO_H
#define ENDERECO_H
#include <iostream>


class Endereco
{
public:
    Endereco();
    Endereco(std::string log, std::string num,
             std::string bair,
             std::string cid,
             std::string est,
             std::string cep,
             double valorImovel,
             int statusImovel,
             std::string anuncioImovel);

    void setLogradouro(std::string log);
    void setNumero(std::string num);
    void setBairro(std::string bair);
    void setCidade(std::string cid);
    void setEstado(std::string est);
    void setCEP(std::string cep);
    void setValor(double valorImovel);
    void setStatus(int statusImovel);
    void setAnuncio(std::string anuncioImovel);

    std::string getLogradouro();
    std::string getNumero();
    std::string getBairro();
    std::string getCidade();
    std::string getEstado();
    std::string getCEP();
    double getValor();
    int getStatus();
    std::string getAnuncio();

    int contaImovel(int tipo);
    void setTipo(int tipo);
    int getTipo();

    std::string logradouro;
    std::string numero;
    std::string bairro;
    std::string cidade;
    std::string estado;
    std::string CEP;
    double valor;
    int status; //vender ou alugar
    std::string anuncio;
    int tipo;

private:

};

#endif // ENDERECO_H
