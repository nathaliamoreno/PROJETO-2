#ifndef IMOVEL_H
#define IMOVEL_H
#include "Endereco.h"
#include "Casa.h"
#include "Apartamento.h"
#include "Terreno.h"
#include <iostream>


class Imovel
{
    public:
        Imovel();

        void ExibeMenu();
        void ExibeSubMenu();
        void Cadastro(int i);
        void ExibeLista(int i);
        void PorTipo(int i);
        void PorStatus(int i);
        void PorBairro(int i);
        void PorCidade(int i);
        void PorValor(int i);
        void Edita(int sel);
        void ExcluirImovel(int sel);
        int lerDados();
        void salvaDados(int i);


    private:
};

#endif // IMOVEL_H
