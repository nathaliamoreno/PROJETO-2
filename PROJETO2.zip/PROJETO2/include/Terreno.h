#ifndef TERRENO_H
#define TERRENO_H
#include "Endereco.h"

class Terreno : public Endereco
{
    public:
        Terreno();
        Terreno(double area);

        void setAreaT(double area);
        double getAreaT();


    double areaT;


    private:
};

#endif // TERRENO_H
