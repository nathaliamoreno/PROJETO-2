#include "Apartamento.h"
#include <iostream>

Apartamento::Apartamento(){

}
Apartamento::Apartamento(std::string pos, std::string quart, std::string And, std::string areaAP, std::string vaga, std::string valorCon){
    posicao = pos;
    nQuartos = quart;
    andar = And;
    areaApt = areaAP;
    vagas = vaga;
    valorCond = valorCon;
}
void Apartamento::setPosicao(std::string pos){
    posicao = pos;
}
void Apartamento::setQuartos(std::string quartos){
    nQuartos = quartos;
}
void Apartamento::setAndar (std::string And){
    andar = And;
}
void Apartamento::setAreaAPT(std::string aAP){
    areaApt = aAP;
}
void Apartamento::setVagas (std::string vaga){
    vagas = vaga;
}
void Apartamento::setValorCondominio(std::string valorCon){
    valorCond = valorCon;
}
std::string Apartamento::getPosicao(){
    return posicao;
}
std::string Apartamento::getQuartos(){
    return nQuartos;
}
std::string Apartamento::getAndar(){
    return andar;
}
std::string Apartamento::getAreaAPT(){
    return areaApt;
}
std::string Apartamento::getVagas(){
    return vagas;
}
std::string Apartamento::getValorCondominio(){
    return valorCond;
}
