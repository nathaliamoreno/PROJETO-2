#include "Endereco.h"



Endereco::Endereco()
{
}

Endereco::Endereco(std::string log, std::string num, std::string bair, std::string cid, std::string est, std::string cep, double valorImovel, int statusImovel, std::string anuncioImovel)
{
    logradouro = log;
    numero = num;
    bairro = bair;
    cidade = cid;
    estado = est;
    CEP = cep;
    valor = valorImovel;
    status = statusImovel;
    anuncio =  anuncioImovel;

}
void Endereco::setLogradouro(std::string log)
{
    logradouro = log;
}
void Endereco::setNumero(std::string num)
{
    numero = num;
}
void Endereco::setBairro(std::string bair)
{
    bairro = bair;
}
void Endereco::setCidade(std::string cid)
{
    cidade = cid;
}
void Endereco::setEstado(std::string est)
{
    estado = est;
}
void Endereco::setCEP(std::string cep)
{
    CEP = cep;
}
void Endereco::setValor(double valorImovel)
{
    valor = valorImovel;
}
void Endereco::setStatus(int statusImovel)
{
    status = statusImovel;
}
void Endereco::setAnuncio(std::string anuncioImovel)
{
    anuncio = anuncioImovel;
}
std::string Endereco::getLogradouro()
{
    return logradouro;
}
std::string Endereco::getNumero()
{
    return numero;
}
std::string Endereco::getBairro()
{
    return bairro;
}
std::string Endereco::getCidade()
{
    return cidade;
}
std::string Endereco::getEstado()
{
    return estado;
}
std::string Endereco::getCEP()
{
    return CEP;
}
double Endereco::getValor()
{
    return valor;
}
int Endereco::getStatus()
{
    return status;
}
std::string Endereco::getAnuncio()
{
    return anuncio;
}
void Endereco::setTipo(int Tipo){
    tipo = Tipo;
}
int Endereco::getTipo(){
    return tipo;
}


