#include "Imovel.h"
#include "Endereco.h"
#include "Casa.h"
#include "Apartamento.h"
#include "Terreno.h"
#include <iostream>
#include <stdio.h>
#include <cstdlib>
#include <string>
#include <algorithm>

using namespace std;

Endereco endereco[100];
Casa casa[100];
Apartamento apartamento[100];
Terreno terreno[100];

Imovel::Imovel()
{

}
void Imovel::ExibeMenu(){

    cout << "\n\n" << endl;
    cout << "       ESCOLHA UMA DAS OPCOES ABAIXO:" << endl;
    cout << "________________________________________________\n"<< endl;

    cout << "	1 - CADASTRAR IMOVEL\n\n" << endl;
    cout << "	2 - CONSULTAR\n\n" << endl;
    cout << "	3 - EDITAR\n\n" << endl;
    cout << "	4 - REMOVER\n\n" << endl;
    cout << "	0 - SAIR\n\n"<< endl;
}
void Imovel::ExibeSubMenu(){

        cout << " \n        _______________________________\n" << endl;
        cout << "          ESCOLHA UMA DAS OPCOES ABAIXO:\n" << endl;
        cout << "         _______________________________\n"<< endl;

        cout << "	1 - IMOVEIS DISPONIVEIS\n" << endl;
        cout << "	2 - IMOVEIS POR TIPO\n" << endl;
        cout << "	3 - IMOVEIS POR STATUS\n" << endl; //VVENDER OU ALUGAR
        cout << "	4 - IMOVEIS POR BAIRRO\n"<< endl;
        cout << "	5 - IMOVEIS POR CIDADE\n"<< endl;
        cout << "	6 - IMOVEIS POR VALOR\n" << endl;
        cout << "	7 - VOLTAR AO MENU PRINCIPAL\n" << endl;
}
void Imovel::Cadastro(int i){

    int tipo, auxi;
    double auxd;
    string aux;

        cout << "\n                QUAL O TIPO DE IMOVEL QUE DESEJA CADASTRAR? " << endl;
        cout << "         (Digite o numero correspondente ao que deseja cadastrar)\n" << endl;
        cout << "\n   1 - CASA\n   2 - APARTAMENTO\n   3 - TERRENO\n" << endl;
        cin >> tipo;
        endereco[i].setTipo(tipo);
        cin.ignore();
        system("cls");
        cout << "\n****************************************\n" << endl;
        cout << "***********CADASTRO DE IMOVEL***********\n\n" << endl;


        cout << " << DIGITE O ANUNCIO >>" << endl;
        getline(cin, aux);
        endereco[i].setAnuncio(aux);
        cout << "\n << ENDERECO >>\n" << endl;
        cout << " RUA:" <<  endl;
        getline(cin, aux);
        endereco[i].setLogradouro(aux);
        cout << " NUMERO:" << endl;
        getline(cin, aux);
        endereco[i].setNumero(aux);
        cout << " BAIRRO:" << endl;
        getline(cin, aux);
        endereco[i].setBairro(aux);
        cout << " CIDADE:" << endl;
        getline(cin, aux);
        endereco[i].setCidade(aux);
        cout << " ESTADO:" << endl;
        getline(cin, aux);
        endereco[i].setEstado(aux);
        cout << " CEP:" << endl;
        getline(cin, aux);
        endereco[i].setCEP(aux);

        if (tipo == 1){

            cout << "\n----------INFORMA��ES DO IMOVEL: ---------\n" << endl;
            cout << "<< CASA >>\n"<< endl;
            cout << "Numero de pavimentos:" << endl;
            cin >> auxi;
            casa[i].setPavimentos(auxi);
            cout << "Numero de quartos:" << endl;
            cin >> auxi;
            casa[i].setQuartos(auxi);
            cout <<"Area construida (m2):" << endl;
            cin >> auxd;
            casa[i].setAreaConstruida(auxi);
            cout <<"Area total (m2):" << endl;
            cin >> auxd;
            casa[i].setAreaTerreno(auxi);



        }else if (tipo == 2){

            cout << "\n----------INFORMA��ES DO IMOVEL: ---------\n" << endl;
            cout << "<<APARTAMENTO>>\n"<< endl;
            cout << "Posicao: " << endl;
            cin >> aux;
            apartamento[i].setPosicao(aux);
            cout << "Numero de quartos: " << endl;
            cin >> aux;
            apartamento[i].setQuartos(aux);
            cout << "Andar: " << endl;
            cin >> aux;
            apartamento[i].setAndar(aux);
            cout << "Area (m2): " << endl;
            cin >> aux;
            apartamento[i].setAreaAPT(aux);
            cout << "Vagas na garagem: " << endl;
            cin >> aux;
            apartamento[i].setVagas(aux);
            cout << "Valor do Condominio: R$" << endl;
            cin >> aux;
            apartamento[i].setValorCondominio(aux);

        }else if (tipo == 3){

            cout << "\n----------INFORMA��ES DO IMOVEL: ---------\n" << endl;
            cout << "<<TERRENO>>\n" << endl;
            cout << "Area do Terreno (m2):" << endl;
            cin >> auxd;
            terreno[i].setAreaT(auxd);
        }

        cout << "\nIMOVEL PARA:\n (escolha uma opcao)\n 1 - Alugar\n 2 - Vender " << endl;
        cin >> auxi;
        endereco[i].setStatus(auxi);
        cout << "Valor R$: " << endl;
        cin >> auxd;
        endereco[i].setValor(auxd);
        cout << "\n\n\n CADASTRO REALIZADO COM SUCESSO!!\n\n\n" << endl;
        i++;
}
void Imovel::ExibeLista(int i){
     int j = 0;
        for(j=0; j<i; j++){
            if (endereco[j].getStatus() !=3){
            cout << "\n IMOVEL [" <<  j << "]" << endl;
            cout << endereco[j].getAnuncio() << endl;
            cout << "______________________" << endl;
            }
        }
}
void Imovel::PorTipo(int i){
     int t, j=0;
            cout << "\n**** CONSULTA POR TIPO ****\n" << endl;
            cout << " QUE TIPO DE IMOVEL DESEJA CONSULTAR? " << endl;
            cout << " (Escolha uma das opcoes abaixo) \n\n 1- CASA \n 2- APARTAMENTO\n 3- TERRENO" <<endl;
            cin >> t;

            for(j=0; j<i; j++){
                if (endereco[j].getStatus() !=3){
                    if(endereco[j].getTipo() == t){
                        cout << "\n IMOVEL [" <<  j << "]" << endl;
                        cout << "\n ANUNCIO : " << endereco[j].getAnuncio()<< endl;
                        cout << "Rua: " << endereco[j].getLogradouro() << endl;
                        cout << "Numero: " << endereco[j].getNumero() << endl;
                        cout << "Bairro: " << endereco[j].getBairro() << endl;
                        cout << "Cidade: " << endereco[j].getCidade() << endl;
                        cout << "Estado: " << endereco[j].getEstado() << endl;
                        cout << "CEP: " << endereco[j].getCEP() << endl;

                        if (t == 1){
                            cout << "Pavimentos: " << casa[j].getPavimentos() << endl;
                            cout << "Quartos: " << casa[j].getQuartos() << endl;
                            cout << "Area do terreno(m2): " << casa[j].getAreaTerreno() << endl;
                            cout << "Area Construida(m2): " << casa[j].getAreaConstruida() << endl;

                        }else if (t == 2){
                            cout << "Posicao: " << apartamento[j].getPosicao() << endl;
                            cout << "Quartos: " << apartamento[j].getQuartos() << endl;
                            cout << "Andar: " << apartamento[j].getAndar() << endl;
                            cout << "Area(m2): " << apartamento[j].getAreaAPT() << endl;
                            cout << "Vagas de garagem: " << apartamento[j].getVagas() << endl;
                            cout << "Valor do Condominio: R$ " << apartamento[j].getValorCondominio() << endl;

                        }else if (t == 3){
                            cout << "Area do terreno(m2): " << terreno[j].getAreaT() << endl;
                        }
                     cout << "Valor: R$ " << endereco[j].getValor() << endl;
            }
        }
    }
}
void Imovel::PorStatus(int i){
    int s, j=0;

            cout << " CONSULTA POR STATUS DO IMOVEL \n" << endl;
            cout << "(Escolha uma das opcoes abaixo) \n\n 1- IMOVEL PARA ALUGAR \n 2- IMOVEL PARA VENDER" << endl;
            cin >> s;

             for(j=0; j<i; j++){
                if(endereco[j].status == s){

                    cout << "\n IMOVEL [" <<  j << "]" << endl;
                    cout << "\n ANUNCIO : " << endereco[j].getAnuncio()<< endl;
                    cout << "Rua: " << endereco[j].getLogradouro() << endl;
                    cout << "Numero: " << endereco[j].getNumero() << endl;
                    cout << "Bairro: " << endereco[j].getBairro() << endl;
                    cout << "Cidade: " << endereco[j].getCidade() << endl;
                    cout << "Estado: " << endereco[j].getEstado() << endl;
                    cout << "CEP: " << endereco[j].getCEP() << endl;

                    if (endereco[j].getTipo() == 1){
                        cout << "Pavimentos: " << casa[j].getPavimentos() << endl;
                        cout << "Quartos: " << casa[j].getQuartos() << endl;
                        cout << "Area do terreno(m2): " << casa[j].getAreaTerreno() << endl;
                        cout << "Area Construida(m2): " << casa[j].getAreaConstruida() << endl;

                    }else if (endereco[j].getTipo() == 2){
                        cout << "Posicao: " << apartamento[j].getPosicao() << endl;
                        cout << "Quartos: " << apartamento[j].getQuartos() << endl;
                        cout << "Andar: " << apartamento[j].getAndar() << endl;
                        cout << "Area(m2): " << apartamento[j].getAreaAPT() << endl;
                        cout << "Vagas de garagem: " << apartamento[j].getVagas() << endl;
                        cout << "Valor do Condominio: R$ " << apartamento[j].getValorCondominio() << endl;

                    }else if (endereco[j].getTipo() == 3){
                        cout << "Area do terreno(m2): " << terreno[j].getAreaT() << endl;
                    }
                 cout << "Valor: R$ " << endereco[j].getValor() << endl;

                } //encerra if do for op3

             }// Encerra for op3
}
void Imovel::PorBairro(int i){

        std::string s, str;
        int j=0;

        cout << " CONSULTA POR BAIRRO " << endl;
        cout << "(Digite o nome do BAIRRO que deseja consultar)\n " << endl;
        cin >> s;

        std::transform(s.begin(), s.end(), s.begin(), :: toupper);
        for(j=0; j<i; j++){

          str = endereco[j].getBairro();
          std:transform(str.begin(), str.end(), str.begin(), :: toupper);
            if (endereco[j].getStatus() !=3){
                if(s == str || str.substr(0,2) == s.substr(0,2)){
                        cout << "\n IMOVEL [" <<  j << "]" << endl;
                        cout << "\n ANUNCIO : " << endereco[j].getAnuncio()<< endl;
                        cout << "Rua: " << endereco[j].getLogradouro() << endl;
                        cout << "Numero: " << endereco[j].getNumero() << endl;
                        cout << "Bairro: " << endereco[j].getBairro() << endl;
                        cout << "Cidade: " << endereco[j].getCidade() << endl;
                        cout << "Estado: " << endereco[j].getEstado() << endl;
                        cout << "CEP: " << endereco[j].getCEP() << endl;
                        if (endereco[j].getTipo() == 1){
                            cout << "Pavimentos: " << casa[j].getPavimentos() << endl;
                            cout << "Quartos: " << casa[j].getQuartos() << endl;
                            cout << "Area do terreno(m2): " << casa[j].getAreaTerreno() << endl;
                            cout << "Area Construida(m2): " << casa[j].getAreaConstruida() << endl;

                        }else if (endereco[j].getTipo() == 2){
                            cout << "Posicao: " << apartamento[j].getPosicao() << endl;
                            cout << "Quartos: " << apartamento[j].getQuartos() << endl;
                            cout << "Andar: " << apartamento[j].getAndar() << endl;
                            cout << "Area(m2): " << apartamento[j].getAreaAPT() << endl;
                            cout << "Vagas de garagem: " << apartamento[j].getVagas() << endl;
                            cout << "Valor do Condominio: R$ " << apartamento[j].getValorCondominio() << endl;

                        }else if (endereco[j].getTipo() == 3){
                            cout << "Area do terreno(m2): " << terreno[j].getAreaT() << endl;
                        }
                     cout << "Valor: R$ " << endereco[j].getValor() << endl;

                }
            }
        }//encerra for
}//encerra por bairro
void Imovel::PorCidade(int i){
        std::string s, str;
        int j=0;

        cout << "**** CONSULTA POR CIDADE ****" << endl;
        cout << "(Digite o nome da CIDADE que deseja consultar)\n " << endl;
        cin >> s;

        std::transform(s.begin(), s.end(), s.begin(), :: toupper);

        for(j=0; j<i; j++){

         str = endereco[j].getCidade();
         std:transform(str.begin(), str.end(), str.begin(), :: toupper);
        if (endereco[j].getStatus() !=3){
                if(s == str || str.substr(0,2) == s.substr(0,2)){
                        cout << "\n IMOVEL [" <<  j << "]" << endl;
                        cout << "\n ANUNCIO : " << endereco[j].getAnuncio()<< endl;
                        cout << "Rua: " << endereco[j].getLogradouro() << endl;
                        cout << "Numero: " << endereco[j].getNumero() << endl;
                        cout << "Bairro: " << endereco[j].getBairro() << endl;
                        cout << "Cidade: " << endereco[j].getCidade() << endl;
                        cout << "Estado: " << endereco[j].getEstado() << endl;
                        cout << "CEP: " << endereco[j].getCEP() << endl;
                        if (endereco[j].getTipo() == 1){
                            cout << "Pavimentos: " << casa[j].getPavimentos() << endl;
                            cout << "Quartos: " << casa[j].getQuartos() << endl;
                            cout << "Area do terreno(m2): " << casa[j].getAreaTerreno() << endl;
                            cout << "Area Construida(m2): " << casa[j].getAreaConstruida() << endl;

                        }else if (endereco[j].getTipo() == 2){
                            cout << "Posicao: " << apartamento[j].getPosicao() << endl;
                            cout << "Quartos: " << apartamento[j].getQuartos() << endl;
                            cout << "Andar: " << apartamento[j].getAndar() << endl;
                            cout << "Area(m2): " << apartamento[j].getAreaAPT() << endl;
                            cout << "Vagas de garagem: " << apartamento[j].getVagas() << endl;
                            cout << "Valor do Condominio: R$ " << apartamento[j].getValorCondominio() << endl;

                        }else if (endereco[j].getTipo() == 3){
                            cout << "Area do terreno(m2): " << terreno[j].getAreaT() << endl;
                        }
                     cout << "Valor: R$ " << endereco[j].getValor() << endl;

                }
            }
        }//encerra for
}//encerra por cidade

void Imovel::PorValor(int i){

        double v1, v2;
        int j;

        cout << "**** CONSULTA POR VALOR ****" << endl;
        cout << "(Digite os valores desejados) \n " << endl;
        cout << "De R$ " << endl;
        cin >> v1;
        cout << "Ate R$ " << endl;
        cin >> v2;


        for(j=0; j<i; j++){
            if (endereco[j].getStatus() !=3){
                if(endereco[j].getValor() >= v1 && endereco[j].getValor() <= v2){
                        cout << "\n IMOVEL [" <<  j << "]" << endl;
                        cout << "\n ANUNCIO : " << endereco[j].getAnuncio()<< endl;
                        cout << "Rua: " << endereco[j].getLogradouro() << endl;
                        cout << "Numero: " << endereco[j].getNumero() << endl;
                        cout << "Bairro: " << endereco[j].getBairro() << endl;
                        cout << "Cidade: " << endereco[j].getCidade() << endl;
                        cout << "Estado: " << endereco[j].getEstado() << endl;
                        cout << "CEP: " << endereco[j].getCEP() << endl;
                        if (endereco[j].getTipo() == 1){
                            cout << "Pavimentos: " << casa[j].getPavimentos() << endl;
                            cout << "Quartos: " << casa[j].getQuartos() << endl;
                            cout << "Area do terreno(m2): " << casa[j].getAreaTerreno() << endl;
                            cout << "Area Construida(m2): " << casa[j].getAreaConstruida() << endl;

                        }else if (endereco[j].getTipo() == 2){
                            cout << "Posicao: " << apartamento[j].getPosicao() << endl;
                            cout << "Quartos: " << apartamento[j].getQuartos() << endl;
                            cout << "Andar: " << apartamento[j].getAndar() << endl;
                            cout << "Area(m2): " << apartamento[j].getAreaAPT() << endl;
                            cout << "Vagas de garagem: " << apartamento[j].getVagas() << endl;
                            cout << "Valor do Condominio: R$ " << apartamento[j].getValorCondominio() << endl;

                        }else if (endereco[j].getTipo() == 3){
                            cout << "Area do terreno(m2): " << terreno[j].getAreaT() << endl;
                        }
                     cout << "Valor: R$ " << endereco[j].getValor() << endl;
                }
            }
    }
}
void Imovel::Edita(int sel){

    int i=0, tipo, auxi;
    double auxd;
    string aux;

        i = sel;

        cout << "\n                QUAL O TIPO DE IMOVEL QUE DESEJA EDITAR? " << endl;
        cout << "         (Digite o numero correspondente ao que deseja cadastrar)\n" << endl;
        cout << "\n   1 - CASA\n   2 - APARTAMENTO\n   3 - TERRENO\n" << endl;
        cin >> tipo;
        endereco[i].setTipo(tipo);
        cin.ignore();
        system("cls");
        cout << "\n****************************************\n" << endl;
        cout << "***********CADASTRO DE IMOVEL***********\n\n" << endl;


        cout << " << DIGITE O ANUNCIO >>" << endl;
        getline(cin, aux);
        endereco[i].setAnuncio(aux);
        cout << "\n << ENDERECO >>\n" << endl;
        cout << " RUA:" <<  endl;
        getline(cin, aux);
        endereco[i].setLogradouro(aux);
        cout << " NUMERO:" << endl;
        getline(cin, aux);
        endereco[i].setNumero(aux);
        cout << " BAIRRO:" << endl;
        getline(cin, aux);
        endereco[i].setBairro(aux);
        cout << " CIDADE:" << endl;
        getline(cin, aux);
        endereco[i].setCidade(aux);
        cout << " ESTADO:" << endl;
        getline(cin, aux);
        endereco[i].setEstado(aux);
        cout << " CEP:" << endl;
        getline(cin, aux);
        endereco[i].setCEP(aux);

        if (tipo == 1){

            cout << "\n----------INFORMA��ES DO IMOVEL: ---------\n" << endl;
            cout << "<< CASA >>\n"<< endl;
            cout << "Numero de pavimentos:" << endl;
            cin >> auxi;
            casa[i].setPavimentos(auxi);
            cout << "Numero de quartos:" << endl;
            cin >> auxi;
            casa[i].setQuartos(auxi);
            cout <<"Area construida (m2):" << endl;
            cin >> auxd;
            casa[i].setAreaConstruida(auxi);
            cout <<"Area total (m2):" << endl;
            cin >> auxd;
            casa[i].setAreaTerreno(auxi);



        }else if (tipo == 2){

            cout << "\n----------INFORMA��ES DO IMOVEL: ---------\n" << endl;
            cout << "<<APARTAMENTO>>\n"<< endl;
            cout << "Posicao: " << endl;
            cin >> aux;
            apartamento[i].setPosicao(aux);
            cout << "Numero de quartos: " << endl;
            cin >> aux;
            apartamento[i].setQuartos(aux);
            cout << "Andar: " << endl;
            cin >> aux;
            apartamento[i].setAndar(aux);
            cout << "Area (m2): " << endl;
            cin >> aux;
            apartamento[i].setAreaAPT(aux);
            cout << "Vagas na garagem: " << endl;
            cin >> aux;
            apartamento[i].setVagas(aux);
            cout << "Valor do Condominio: R$" << endl;
            cin >> aux;
            apartamento[i].setValorCondominio(aux);

        }else if (tipo == 3){

            cout << "\n----------INFORMA��ES DO IMOVEL: ---------\n" << endl;
            cout << "<<TERRENO>>\n" << endl;
            cout << "Area do Terreno (m2):" << endl;
            cin >> auxd;
            terreno[i].setAreaT(auxd);
        }

        cout << "\nIMOVEL PARA:\n (escolha uma opcao)\n 1 - Alugar\n 2 - Vender " << endl;
        cin >> auxi;
        endereco[i].setStatus(auxi);
        cout << "Valor R$: " << endl;
        cin >> auxd;
        endereco[i].setValor(auxd);
        cout << "\n\n\n CADASTRO REALIZADO COM SUCESSO!!\n\n\n" << endl;
}
void Imovel::ExcluirImovel(int sel){

        endereco[sel].setStatus(3);
        casa[sel].setStatus(3);
        apartamento[sel].setStatus(3);
        terreno[sel].setStatus(3);
        system ("cls");
        cout << "\n\nIMOVEL EXCLUIDO COM SUCESSO! " << endl;
}
